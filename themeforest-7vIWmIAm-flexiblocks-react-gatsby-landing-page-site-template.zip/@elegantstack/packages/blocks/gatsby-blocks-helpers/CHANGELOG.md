# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## 2.0.0 (2021-03-17)

### Refactor

- **gatsby-blocks-helpers:** rename @elegantstack/blocks-helpers package to @elegantstack/gatsby-blocks-helpers ([9ac063d](https://gitlab.com/alimoosavi15/gatsby-theme-flexiblog/commit/9ac063d41e2f80796f28ef3a61bbf7344e592f70))

## 1.0.1 (2021-02-25)

### Refactor

- **core-blocks, helpers-blocks:** change package names ([09a3ef2](https://gitlab.com/alimoosavi15/gatsby-theme-flexiblog/commit/09a3ef2826b501c6337ce6f516049f3870a98dff))
