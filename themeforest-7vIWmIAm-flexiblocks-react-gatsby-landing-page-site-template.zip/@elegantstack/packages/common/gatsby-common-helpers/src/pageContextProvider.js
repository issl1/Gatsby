import React from 'react'

const pageContextProvider = React.createContext()

export default pageContextProvider
