module.exports = pluginOptions => ({
  localPaths: pluginOptions.localPaths || []
})
