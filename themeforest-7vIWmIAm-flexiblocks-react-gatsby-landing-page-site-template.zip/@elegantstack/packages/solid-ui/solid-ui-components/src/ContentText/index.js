export { default } from './ContentText'
