export { default } from './ContentIcon'
