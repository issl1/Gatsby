export { default } from './FlexImage'
