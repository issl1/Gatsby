export { default } from './PoweredByGatsby'
