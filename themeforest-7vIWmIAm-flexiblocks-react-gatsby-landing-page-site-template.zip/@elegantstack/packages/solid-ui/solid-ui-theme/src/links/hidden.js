export default {
  userSelect: `none`,
  cursor: `default`,
  color: `rgba(0,0,0,0)`,
  '& > div:first-of-type': {
    display: [`none`, null, `inherit`]
  }
}
