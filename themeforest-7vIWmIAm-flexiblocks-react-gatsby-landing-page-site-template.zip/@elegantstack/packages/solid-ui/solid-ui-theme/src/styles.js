export default {
  /** Root (body tag) */
  root: {
    WebkitFontSmoothing: `antialiased`,
    textDecoration: `none`,
    overflowX: `hidden`
  }
}
