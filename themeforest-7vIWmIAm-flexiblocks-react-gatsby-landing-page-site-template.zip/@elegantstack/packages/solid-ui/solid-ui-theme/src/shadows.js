export default {
  none: `none`,
  default: `0 0 35px rgba(140,152,164,.125)`,
  lg: `0px 5px 25px rgba(28,33,54,.1)`,
  xl: `0 0.25rem 0.5rem rgb(0,0,0,0.05), 0 1.5rem 2.2rem rgb(0,0,0,0.1)`
}
